
  # Albundle Mobile App MVP

  This is a code bundle for Albundle Mobile App MVP. The original project is available at https://www.figma.com/design/94TKSDiY3Mg94iqWyHcYTt/Albundle-Mobile-App-MVP.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  